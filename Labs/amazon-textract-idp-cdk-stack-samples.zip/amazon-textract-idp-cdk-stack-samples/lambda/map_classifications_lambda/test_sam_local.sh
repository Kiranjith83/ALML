sam build
sam local invoke -e events/event.json -n env.json
